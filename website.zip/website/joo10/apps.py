from django.apps import AppConfig


class Joo10Config(AppConfig):
    name = 'joo10'
