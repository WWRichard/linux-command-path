from django.shortcuts import render
from django.http import HttpResponse,FileResponse
from . import models
import time,datetime,requests,sys,os,pandas
sys.path.append('..')
from commonBid import saveBids
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _  #多国语言

from django.utils.translation import activate,get_language
import shutil

# Create your views here.
def login(request):
    respones = render(request,'login.html')
    return respones

def dailyBids(request):
    '''
    try:
        os.remove('./static/dailyBids/db.sqlite4')
    except Exception as e:
        print('del db Error')
    try:
        shutil.copy('./db.sqlite3', './static/dailyBids/db.sqlite3')
    except IOError as e:
        print("Unable to copy file. %s" % e)
    except:
        print("Unexpected error:", sys.exc_info())
    '''
    retData = {}
    retData['fileList'] = os.listdir('./static/dailyBids')
    respones = render(request,'dailyBids.html',retData)
    return respones

def dailyPy(request):
    retData = {}
    retData['fileListpy'] = os.listdir('./static/BidLog')
    respones = render(request,'dailyResult.html',retData)
    return respones   

def strToInt(strIn):
    if strIn == '':return 0
    try:
        return int(strIn)
    except: return 0

def addBids(uID,jooID,bidID,bidRanking1,bidPriceMax1,bidRanking2,bidPriceMax2,bidRanking3,bidPriceMax3):
    bidCurrent = models.currentBid.objects.filter(jooID=str(jooID), bidID=str(bidID))
    plusKey = _('1先刷新投标历史')
    plusStr = _('1请检查账号标号')
    print(len(bidCurrent))
    if len(bidCurrent) > 0:
        plusKey = bidCurrent[0].bidPlusKey
        plusStr = bidCurrent[0].bidPlusStr
    findBid = models.joo10Bid.objects.filter(userID=uID,jooID=jooID,bidID=int(bidID))
    models.userInfo.objects.filter(userID=uID).update(userCurrentJooID=jooID)
    if len(findBid) > 0:
        findBid.update(
        bidRanking1=bidRanking1,bidPriceMax1=bidPriceMax1,bidRanking2=bidRanking2,bidPriceMax2=bidPriceMax2,bidRanking3=bidRanking3,bidPriceMax3=bidPriceMax3,
        bidRanking1T=bidRanking1,bidPriceMax1T=bidPriceMax1,bidRanking2T=bidRanking2,bidPriceMax2T=bidPriceMax2,bidRanking3T=bidRanking3,bidPriceMax3T=bidPriceMax3,
        bidPlusKey = plusKey,bidPlusStr = plusStr)
    else:
        models.joo10Bid.objects.create(userID=uID, jooID=jooID,bidID=int(bidID),
        bidRanking1=bidRanking1,bidPriceMax1=bidPriceMax1,bidRanking2=bidRanking2,bidPriceMax2=bidPriceMax2,bidRanking3=bidRanking3,bidPriceMax3=bidPriceMax3,
        bidRanking1T=bidRanking1,bidPriceMax1T=bidPriceMax1,bidRanking2T=bidRanking2,bidPriceMax2T=bidPriceMax2,bidRanking3T=bidRanking3,bidPriceMax3T=bidPriceMax3,
        bidPlusKey = plusKey,bidPlusStr = plusStr)

def user(request):    
    uID = request.get_signed_cookie('login',salt='s28',default='')
    currentUser = models.userInfo.objects.filter(userID=uID)
    # if len(currentUser) > 0:
    #     old_lang = get_language()
    #     if 'zh-hans' != old_lang:
    #          currentUser.update(userLanguage = old_lang)
    #     activate(currentUser[0].userLanguage)

    '''
    if uID == '':
        respones = render(request,'login.html')
        return respones        
    '''
    
    retData = {'id':uID}
    orderTabel = 'Qoo10Bid'
    orderType = 'asc'
    orderKey  = 'bidPlusStr'
    newCome = False
    if request.method == 'POST' :
        if 'Email' in request.POST and 'Password' in request.POST:
            userID = request.POST['Email']
            userPW = request.POST['Password']
            findUser = models.userInfo.objects.filter(userID=userID)
            if len(findUser) > 0:
                inIt = False
                for user in findUser:
                    if user.userPW == userPW:
                        inIt = True
                        break
                if not inIt:
                    return render(request,'login.html',{'id':userID,'errorMessage':_('密码错误，请重新输入或联系客服')})     
                else:  #老用户来了
                    newCome = True
                    uID = userID
                    if uID == 'chinazyl2013@163.com':
                        return render(request,'login.html',{'id':userID,'errorMessage':_('已限制登录，请联系客服')})
                    retData = {'id':uID}
                    models.userInfo.objects.filter(userID=uID).update(userUpdateBool=True)
            else:   #新用户
                return render(request,'login.html',{'id':userID,'errorMessage':_('请重新确认帐号密码或者联系客服')})
                #models.userInfo.objects.create(userID=userID,userPW=userPW)  #存数据库再返回数据
                #newCome = True
                #uID = userID
                #retData = {'id':uID}
            if uID != 'du6666@outlook.com':
                if 'HTTP_X_FORWARDED_FOR' in  request.META:
                    ip =  request.META['HTTP_X_FORWARDED_FOR']
                else:
                    ip = request.META['REMOTE_ADDR']
                ipRecodes = models.userIPRecode.objects.filter(userID = uID)
                ipI = models.newComeIP.objects.filter(comeIP=ip)
                if len(ipI) > 0:
                    models.userIPRecode.objects.create(userID=uID,IPadd=ip,country_name=ipI[0].country_name,city=ipI[0].city,state=ipI[0].state,
                    latitude=ipI[0].latitude,longitude=ipI[0].longitude,comeTimes=len(ipI))
        elif 'jooAcAdd' in request.POST:                
            jooID = request.POST['account']
            jooPW = request.POST['password']
            jooAc = models.joo10Account.objects.filter(userID = uID, jooID = jooID)
            if len(jooAc) > 0:
                jooAc.update(jooPW = jooPW)
            else:
                jooAc = models.joo10Account.objects.filter(jooID=jooID)
                if len(jooAc) > 0:
                    retData['errorMessage'] = _('账号已存在')
                else:
                    models.joo10Account.objects.create(userID = uID, jooID = jooID, jooPW = jooPW, jooRun = False)
        elif 'jooAcDel' in request.POST:
            jooID = request.POST['jooAcDel']
            models.joo10Account.objects.filter(userID = uID, jooID = jooID).delete()
        elif 'bidItemAdd' in request.POST:
            rp = request.POST
            addBids(uID,rp['jooID'],rp['bidID'],strToInt(rp['bidRanking1']),strToInt(rp['bidPriceMax1']),
            strToInt(rp['bidRanking2']),strToInt(rp['bidPriceMax2']),strToInt(rp['bidRanking3']),strToInt(rp['bidPriceMax3']))
        elif 'bidDel' in request.POST:
            bidID = request.POST['bidDel']
            models.joo10Bid.objects.filter(userID=uID,bidID=int(bidID)).delete()
        elif 'uploadFile' in request.POST:
            obj = request.FILES.get('info_file')
            if obj:
                if obj.name.find('.xlsx') >= 0 and obj.size < 20000:
                    baseDir = os.path.dirname(os.path.abspath(__name__))
                    filename = os.path.join(baseDir, 'upload', uID+'.xlsx')#filename = os.path.join(orderDir, obj.name)
                    fobj = open(filename, 'wb')
                    for chrunk in obj.chunks():
                        fobj.write(chrunk)
                    fobj.close()
                    pf = pandas.read_excel(filename,keep_default_na=False)#,encoding='unicode_escape'
                    print(len(pf))
                    for v in pf.values:
                        print(v)
                        addBids(uID,v[0],v[1],strToInt(v[2]),strToInt(v[3]),strToInt(v[4]),strToInt(v[5]),strToInt(v[6]),strToInt(v[7]))
                else:
                    print('文件类型错误或者文件过大，不保存')
        elif 'refreshBid' in request.POST: #userTest 1 更新列表
            sessionList = []
            saveBids(sessionList,uID)
            models.userInfo.objects.filter(userID=uID).update(updateBidsTime=timezone.now(),userUpdateBool=False)
        elif 'delAllBids' in request.POST:
            models.joo10Bid.objects.filter(userID=uID).delete()
    else:   #非POST 请求
        if request.method == 'GET':
            if 'orderTabel' in request.GET and 'orderKey' in request.GET and 'orderType' in request.GET:
                orderTabel = request.GET['orderTabel']
                orderType = request.GET['orderType']
                orderKey  = request.GET['orderKey']
            if 'download' in request.GET or 'downloadpy' in request.GET:
                if 'download' in request.GET:
                    fn = request.GET['download']
                    downLoadFile = './static/dailyBids/' + fn
                if 'downloadpy' in request.GET:
                    fn = request.GET['downloadpy']
                    downLoadFile = './static/BidLog/' + fn
                file=open(downLoadFile,'rb')
                response =FileResponse(file)
                response['Content-Type']='application/octet-stream'
                response['Content-Disposition']='attachment;filename='+fn
                return response
        else:
            if len(uID) <= 0:
                return render(request,'login.html')
    bids = models.joo10Bid.objects.filter(userID = uID)
    for bid in bids:
        checkCnt = models.joo10Bid.objects.filter(userID=uID, bidPlusStr=bid.bidPlusStr,bidRanking1=bid.bidRanking1)
        if len(checkCnt) >= 2:checkCnt.update(bidBgColor='bg-danger')
        elif bid.bidPlusStr == '':checkCnt.update(bidBgColor='bg-warning')#bg-info
        else: checkCnt.update(bidBgColor='')
    if orderTabel == '' or orderKey == '' or orderType == '':
        currentBids = models.currentBid.objects.filter(userID = uID)
        bids = models.joo10Bid.objects.filter(userID = uID)
        orderType = 'asc'
    else:
        orderKeyForModels = ''
        orderDir = ''
        if orderType == 'asc':orderDir = '-';orderType = 'desc'
        else:orderType = 'asc'
        orderKeyForModels = orderDir + orderKey
        if orderTabel == 'currentBid':
            currentBids = models.currentBid.objects.filter(userID = uID).order_by(orderKeyForModels)
            bids = models.joo10Bid.objects.filter(userID = uID)
        elif orderTabel == 'Qoo10Bid':
            bids = models.joo10Bid.objects.filter(userID=uID).order_by(orderKeyForModels)
            currentBids = models.currentBid.objects.filter(userID = uID)
    retData['orderType'] = orderType
    joos = models.joo10Account.objects.filter(userID = uID)
    #设置刷新投标历史按键颜色
    timeStr = time.strftime("%a %b %d %Y",time.localtime(time.time()))
    timeNowSec = time.mktime(time.strptime(timeStr,"%a %b %d %Y")) - 24 * 3600 + 16 * 3600 + 50 * 60
    
    if len(currentUser) > 0:
        #updateBidsTime = time.mktime(currentUser[0].updateBidsTime.timetuple())#上次刷新投票历史时间
        #if timeNowSec > updateBidsTime:#如果今天没有点刷新投标历史，把按键显示为红色
        if currentUser[0].userUpdateBool:
            retData['buttonColor'] = 'btn-danger'
        else: retData['buttonColor'] = 'btn-primary'
    
    if len(bids) > 0:#旧标删除    
        createTime = time.mktime(bids[0].bidCreateTime.timetuple()) + 8 * 3600
        if timeNowSec > createTime:
            bids.delete()
            bids = []
    if len(joos) > 0: retData['jooAcs'] = joos
    if len(bids) > 0: 
        retData['bids'] = bids
        if bids[0].bidWinInd > 0: retData['showBidResult'] = 'Yes'
    if len(currentUser) > 0: retData['jooCurrent'] = currentUser[0].userCurrentJooID
    if len(currentBids) > 0: retData['currentBids'] = currentBids
    respones = render(request,'user.html',retData)
    if newCome: respones.set_signed_cookie('login',userID,salt='s28',max_age=20 * 60 * 60,httponly=True)
    return respones
