from django.db import models

# Create your models here.
class userInfo(models.Model):
    userID = models.CharField(max_length=32)
    userPW = models.CharField(max_length=32)
    userLanguage = models.CharField(max_length=32,default='en')
    userCurrentJooID = models.CharField(max_length=32,default='')
    userType = models.IntegerField(default=0)
    userTest = models.IntegerField(default=0)
    updateBidsTime  = models.DateTimeField(auto_now=True,editable=True,null=True)
    userUpdateBool = models.BooleanField(default = True)

class newComeIP(models.Model):
    comeIP = models.CharField(max_length=32,default='')
    comeTime = models.DateTimeField(auto_now_add=True)
    comeAllow = models.BooleanField(default=True)
    comeCountry = models.CharField(max_length=32,default='')
    country_name = models.CharField(max_length=32,default='')
    city = models.CharField(max_length=32,default='')
    postal = models.CharField(max_length=32,default='')
    latitude = models.CharField(max_length=32,default='')
    longitude = models.CharField(max_length=32,default='')
    state = models.CharField(max_length=32,default='')
    comeTimes = models.IntegerField(default=1)

class userIPRecode(models.Model):
    userID = models.CharField(max_length=32)
    IPadd = models.CharField(max_length=32)
    country_name = models.CharField(max_length=32,default='')
    city = models.CharField(max_length=32,default='')
    state = models.CharField(max_length=32,default='')
    latitude = models.CharField(max_length=32,default='')
    longitude = models.CharField(max_length=32,default='')
    comeTime = models.DateTimeField(auto_now_add=True)
    comeTimes = models.IntegerField(default=1)

class joo10Account(models.Model):
    userID = models.CharField(max_length=32)
    jooID = models.CharField(max_length=32)
    jooPW = models.CharField(max_length=32)
    jooType = models.IntegerField(default=0)
    jooRun = models.BooleanField(default=False)
    jooCookie = models.CharField(max_length=4096)
    jooCookieUpdateTime = models.CharField(max_length=512,default='')
    jooRunPid = models.IntegerField(default=0)
    jooSessionID  = models.IntegerField(default=-1)

class currentBid(models.Model):
    userID = models.CharField(max_length=32,default='')
    jooID = models.CharField(max_length=32,default='')
    bidID = models.CharField(max_length=32,default='')
    bidGoodID = models.CharField(max_length=32,default='')
    bidType = models.CharField(max_length=32,default='')
    bidTitle = models.CharField(max_length=4096,default='')
    bidShowTime = models.CharField(max_length=128,default='')
    bidCurrentRanking = models.CharField(max_length=32,default='')
    bidCurrentPrice   = models.CharField(max_length=32,default='')
    bidCurrentPriceQ = models.CharField(max_length=32,default='')
    bidStartData = models.CharField(max_length=128,default='')
    bidSeqNo = models.CharField(max_length=32,default='')
    bidPlusStr = models.CharField(max_length=128,default='')
    bidPlusKey  = models.CharField(max_length=32,default='')

class joo10Bid(models.Model):
    userID = models.CharField(max_length=32)
    jooID = models.CharField(max_length=32)
    bidID = models.IntegerField(default=0)
    bidRanking1  = models.IntegerField(default=0)
    bidPriceMax1 = models.IntegerField(default=0)
    bidRanking2  = models.IntegerField(default=0)
    bidPriceMax2 = models.IntegerField(default=0)
    bidRanking3  = models.IntegerField(default=0)
    bidPriceMax3 = models.IntegerField(default=0)

    bidRanking1T  = models.IntegerField(default=0)
    bidPriceMax1T = models.IntegerField(default=0)
    bidRanking2T  = models.IntegerField(default=0)
    bidPriceMax2T = models.IntegerField(default=0)
    bidRanking3T  = models.IntegerField(default=0)
    bidPriceMax3T = models.IntegerField(default=0)

    bidRanking4  = models.IntegerField(default=0)
    bidPriceMax4 = models.IntegerField(default=0)
    bidCurrentRanking = models.IntegerField(default=0)  #当前排名
    bidCurrentPrice = models.IntegerField(default=0)  #当前报价
    bidPlusID = models.CharField(max_length=32,default='') #获取价格列表用
    bidPlusType = models.CharField(max_length=32,default='') #获取价格列表用
    bidCategoryCd = models.CharField(max_length=32,default='') #获取价格列表用
    bidSessionID  = models.IntegerField(default=-1)
    bidStartPrice = models.IntegerField(default=0)
    bidUnit = models.IntegerField(default=0)
    bidSeqNo = models.CharField(max_length=32,default='')
    bidPlusBidNo = models.CharField(max_length=32,default='')
    bidSendMessage = models.CharField(max_length=4096,default='')
    bidWinPrice = models.IntegerField(default=0)
    bidWinInd   = models.IntegerField(default=0)
    bidWinTime  = models.DateTimeField(auto_now=True,editable=True,null=True)
    bidCreateTime  = models.DateTimeField(auto_now_add=True,editable=True,null=True)
    bidPlusStr = models.CharField(max_length=128,default='')
    bidPlusKey = models.CharField(max_length=128,default='')
    bidBgColor = models.CharField(max_length=128,default='')