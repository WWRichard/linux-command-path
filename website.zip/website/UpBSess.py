from apscheduler.schedulers.blocking import BlockingScheduler
from commonBid import saveBids
import random

def work(sleepSec):
   sessionList = []
   saveBids(sessionList,'',False,False,True)
   sessionList.clear()
   print('更新BidSessionsID完成')

def workDailyBids(emp):
   sessionList = []
   saveBids(sessionList,'chinazyl2013@163.com',False,True)
   print('workDailyBids got successfully')

updateNow = False
#updateNow = True

if __name__ == "__main__":   
   if updateNow:
      print('Update Sessing Info Runing Now......')
      work(0)
   else:
      print('Update Sessing Info Timer Runing......')
      scheduler = BlockingScheduler()# scheduler.add_job(work,  'interval',minutes = 60)
      scheduler.add_job(work,'cron',day_of_week="0-6",hour=16,minute=45,second=5, args=[0],misfire_grace_time=300)
      scheduler.add_job(work,'cron',day_of_week="0-6",hour=16,minute=46,second=35,args=[0],misfire_grace_time=300)
      #scheduler.add_job(workDailyBids,'cron',day_of_week="0-6",hour=17,minute=1 ,second=random.randint(1,55) ,args=[0],misfire_grace_time=3000)
      scheduler.start()
