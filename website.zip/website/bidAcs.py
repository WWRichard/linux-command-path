from apscheduler.schedulers.blocking import BlockingScheduler
from commonBid import work,setPidForQooID
from os import getpid

debug = False
#debug = True

QooList = ['Jianganming','DENGYAN']
#QooList = []
if __name__ == "__main__":
    if not QooList: #如果没有输入号，去找一个可用的
        Qid = setPidForQooID(getpid())
        if Qid == '': 
            print('无输入且无可用Qoo10号')
        else: 
            QooList.append(Qid)        
    if QooList:#如果列表不为空运行
        print('当前运行Qoo10ID为:',QooList)
        if debug:work(0,QooList,debug)
        else:
            scheduler = BlockingScheduler()
            scheduler.add_job(work,'cron',day_of_week="0-6",hour=16,minute=48,second=0,args=[0,QooList,debug],misfire_grace_time=180)#scheduler.add_job(work,  'interval',minutes = 60)
            scheduler.start()
