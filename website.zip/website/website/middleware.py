from django.http import HttpResponse
from django.utils.deprecation import MiddlewareMixin    # 1.10.x
import sys
sys.path.append("..")
from joo10.models import newComeIP
import time

class TestMiddleware(MiddlewareMixin):
    def process_view(self,request,view_func,*view_args,**view_kwargs):
        #return HttpResponse('<h1>升级维护中，请稍后再试!</h1>') 
        # EXCLUDE_IPS = ['80.82.70.187','216.165.232.144','125.160.153.181','139.224.116.241',
        # '62.234.136.215','139.224.83.64','106.15.95.120','45.33.85.176','173.255.248.253',
        # '172.104.242.173','47.103.88.138']
        nowTime = time.localtime(time.time())
        nowSecs = nowTime.tm_hour * 3600 + nowTime.tm_min * 60 + nowTime.tm_sec
        if nowSecs >= (16 * 3600 + 44 * 60 + 55) and nowSecs < (16 * 3600 + 50 * 60 + 5):
            print(time.localtime(time.time()),"服务器忙，请勿在16点45至16点50分5秒访问")
            return HttpResponse('<h1>服务器忙，请勿在16点45至16点50分5秒访问</h1>') 
        if 'HTTP_X_FORWARDED_FOR' in  request.META:
            ip =  request.META['HTTP_X_FORWARDED_FOR']
        else:
            ip = request.META['REMOTE_ADDR']
        comeIPs = newComeIP.objects.filter(comeIP=ip)
        if len(comeIPs) == 0:
            #Country = checkIPFrom(ip)
            Country,country_name,city,postal,latitude,longitude,state = checkIPFrom(ip)
            if not Country:Country = ''
            if not country_name:country_name  = ''
            if not city:city = ''
            if not postal:postal = ''
            if not latitude:latitude = ''
            if not longitude:longitude = ''
            if not state: state = ''
            if Country != 'CN' and Country != 'KR':
                newComeIP.objects.create(comeIP = ip, comeAllow = False,comeCountry=Country,
                country_name=country_name,city=city,postal=postal,latitude=latitude,longitude=longitude,state=state)
                return HttpResponse('<h1>Have A Good Day</h1>')
            else:
                newComeIP.objects.create(comeIP = ip, comeAllow = True,comeCountry=Country,
                country_name=country_name,city=city,postal=postal,latitude=latitude,longitude=longitude,state=state)
        elif len(comeIPs) == 1:
            if comeIPs[0].comeAllow == False:
                return HttpResponse('<h1>Have A Good Day</h1>')   
        # if ip in EXCLUDE_IPS or checkIPFrom(ip) != 'CN':
        #     return HttpResponse('<h1>Have A Good Day</h1>')

def checkIPFrom(ip):
    import requests
    import json
    with requests.get("https://geolocation-db.com/jsonp/"+ip) as url:
        data = url.text.split("(")[1].strip(")")
        print(data)
        js = json.loads(data)
        #print(js)
        return js['country_code'],js['country_name'],js['city'],js['postal'],js['latitude'],js['longitude'],js['state']