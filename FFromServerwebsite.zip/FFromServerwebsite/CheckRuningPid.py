import os,time
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "website.settings")
import django,psutil
django.setup()
from django.utils import timezone
from joo10.models import joo10Account

def pidRuning(pid):
    for process in psutil.process_iter():
        try:
            processinfo = process.as_dict(attrs=['name','pid'])
        except psutil.NoSuchProcess:
            pass
        else:
            #print(processinfo)
            if pid == processinfo['pid']:return True
    return False

timeStart = 16 * 3600 + 44 * 60 + 0
timeEnd   = 16 * 3600 + 50 * 60 + 10
while True:
    nowTime = time.localtime(time.time())
    nowSecs = nowTime.tm_hour * 3600 + nowTime.tm_min * 60 + nowTime.tm_sec
    if nowSecs >= timeStart and nowSecs <= timeEnd:
        time.sleep(360)
        continue
    joos = joo10Account.objects.all()
    for joo in joos:
        if not pidRuning(joo.jooRunPid):
            joo10Account.objects.filter(jooRunPid=joo.jooRunPid).update(jooRunPid=0)
            print(joo.jooID,'已停止运行，标记已清除，等待新进程')
    time.sleep(3)