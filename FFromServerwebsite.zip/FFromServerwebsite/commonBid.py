import threading,time,os,requests,json,datetime,random,openpyxl
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "website.settings")
import django
django.setup()
from django.utils import timezone
from joo10.models import joo10Account,joo10Bid,currentBid

gloBidDic = {}
lock = threading.Lock()

someBids = {
    #2577215:{'upTo':1000, 'Del':True},
}

onlyDebug = False
manyOrdersSend = False

exitFlag = 0
class ThreadBid (threading.Thread):
    def __init__(self, threadID, name, bidID):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.bidID = bidID
    def run(self):
        #print ("开始线程：" + self.name)
        getPriceListAndBid(self.name,self.bidID)
        #print ("退出线程：" + self.name)

def getNowRanking(priceList,price):
    if len(priceList) <= 1:return 1
    retRanking = 0
    for p in priceList:
        if price > p:break
        retRanking += 1
    return retRanking

def sendPrice(threadName, session,no,pr,ty,ticket,index,updateOrDelete='U'):    
    url = 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/swe_ADPlusBizService.asmx/UpdateBiddingInfoBatch'
    data = {'bids':[
        {'type':updateOrDelete,'seq_no':no,'bid_price':pr,'landing_type':'','landing_url':'','img_url':'','gd_no':'','sid':'','display_type':ty}
    ]}
    re = session.post(url, data = json.dumps(data))#, timeout = (2,2)
    re.encoding = 'utf-8'
    message = ''
    if re.status_code == 200:
        js = re.json()
        if 'd' not in js or 'ResultMsg' not in js['d']:
            message = ('bidReturn:',js,'bidError')
            return message,0
        else:
            js = re.json()['d']['ResultMsg']      
            if js == 'SUCCESS':
                if updateOrDelete == 'U':#更新价格
                    message = threadName, ',投标号：',ticket,'投标成功，中标价：',pr,'名次：',index
                elif updateOrDelete == 'D':
                    message = threadName, ',投标号：',ticket,'取消投标成功，价格：',pr
                return message,int(pr)
            elif js == 'FAIL[-5]':
                message = '现在不是投标时间'
            elif js == 'FAIL[-24]':
                message = 'Qcash不足，请充值'
            else: 
                message = js
    else: 
        print(re.text,'发送投票请求投票失败')
        message = '发送投票请求投票失败'
    msg = ('sendPriceError:',message,'  bidID:', ticket," price:",pr)
    return msg,0

def getPriceListAndBid(threadName,bidID):
    global gloBidDic
    global someBids
    THour = 16
    TMin  = 49
    if bidID in someBids: 
        timeStart   = THour * 3600 + TMin     * 60 + 40
        startAgain  = THour * 3600 + TMin     * 60 + 57.8
    else: timeStart = THour * 3600 + TMin     * 60 + 56
    timeEnd         = THour * 3600 + (TMin+1) * 60 + 0
    dicBid = gloBidDic[bidID]
    bid    = dicBid['bid']
    if not onlyDebug:
        while True:
            nowTime = time.localtime(time.time())
            if (nowTime.tm_hour * 3600 + nowTime.tm_min * 60 + nowTime.tm_sec) >= timeStart:break
            time.sleep(0.1)
        time.sleep(random.randint(1,8) * 0.1)
    someBidSendOK = False
    someBidDelOK  = False
    lastPriceList = []
    sendCnt = 0
    while True:
        if exitFlag:threadName.exit()
        nowTime = time.localtime(time.time())
        nowSeconds = nowTime.tm_hour * 3600 + nowTime.tm_min * 60 + nowTime.tm_sec
        if manyOrdersSend:
            msg,sucPrice = sendPrice(threadName,dicBid['session'], bid.bidSeqNo, str(1000), bid.bidPlusType, bid.bidID, 1)
            if nowSeconds >= timeEnd:break
            sendCnt += 1
            continue
        listPrice = []#开始干活
        try:
            if onlyDebug or bidID not in someBids or nowSeconds > THour * 3600 + TMin * 60 + 55:#处理特殊标
                listPrice = getBidPriceList(dicBid['session'],bid.bidPlusID,bid.bidPlusType,bid.bidCategoryCd)            
        except Exception as e:
            print(bidID, "获取投标列表错误" , e ,end='  ')
        finally:
            if len(listPrice) == 0:
                #print(bidID, "获取投标列表错误，报价列为空")    
                if not onlyDebug:
                    nowTime = time.localtime(time.time())
                    if (nowTime.tm_hour * 3600 + nowTime.tm_min * 60 + nowTime.tm_sec) >= timeEnd:break        
        if not onlyDebug and bidID in someBids:#处理特殊标
            sBi = someBids[bidID]
            if lastPriceList != listPrice:#不停存价格列表
                lock.acquire()
                dicBid['messageUpTo'].append({'plist':listPrice,'time':timezone.now()})
                lock.release()
                lastPriceList = listPrice
            if someBidSendOK == False:
                msg,sucPrice = sendPrice(threadName,dicBid['session'], bid.bidSeqNo, str(sBi['upTo']), bid.bidPlusType, bid.bidID, 1)
                if sucPrice > 0:someBidSendOK = True
                lock.acquire()
                dicBid['price'] = sucPrice
                dicBid['ranking'] = 1
                dicBid['messageUpTo'].append({'msg':msg,'plist':listPrice,'time':timezone.now()})
                lock.release()
            nowTime = time.localtime(time.time())
            nowSeconds = nowTime.tm_hour * 3600 + nowTime.tm_min * 60 + nowTime.tm_sec            
            if nowSeconds < startAgain:
                time.sleep(0.1)
                continue
            else:
                if sBi['Del'] == True:#如果是取消
                    if someBidDelOK == False:#如果还没有取消，取消投标
                        msg,sucPrice = sendPrice(threadName,dicBid['session'], bid.bidSeqNo, str(sBi['upTo']), bid.bidPlusType, bid.bidID, 1,'D')
                        if sucPrice > 0:someBidDelOK = True
                        lock.acquire()
                        dicBid['messageUpTo'].append({'msg':msg,'plist':listPrice,'time':timezone.now()})
                        lock.release()
                    if nowSeconds >= timeEnd:break#最后时间到了，退出
                    continue#如果是要取消的标，下面不再运行
        #print(listPrice)
        #listPrice = [1400,900]#======================================DELETE========================================
        if len(listPrice) == 0:
            if not onlyDebug:continue
            else: return
        nowBidPrice = dicBid['price']
        curInd = getNowRanking(listPrice,nowBidPrice)
        priceAddList = [2621774]
        priceAdd = 0
        if bidID in priceAddList:priceAdd = 12
        listPriceTaget = [
            {'bidRanking':bid.bidRanking1,'bidUnitMul':random.randint(1,3)+priceAdd,'limitPrice':bid.bidPriceMax1},
            {'bidRanking':bid.bidRanking1,'bidUnitMul':1+priceAdd,                  'limitPrice':bid.bidPriceMax1},
            {'bidRanking':bid.bidRanking2,'bidUnitMul':random.randint(1,3)+priceAdd,'limitPrice':bid.bidPriceMax2},
            {'bidRanking':bid.bidRanking2,'bidUnitMul':1+priceAdd,                  'limitPrice':bid.bidPriceMax2},
            {'bidRanking':bid.bidRanking3,'bidUnitMul':random.randint(1,3)+priceAdd,'limitPrice':bid.bidPriceMax3},
            {'bidRanking':bid.bidRanking3,'bidUnitMul':1+priceAdd,                  'limitPrice':bid.bidPriceMax3}]
        for lp in listPriceTaget:
            if lp['bidRanking'] == 0 or lp['limitPrice'] == 0:break#如果没有输入名次或者上限价，不投了
            bidPrice = bid.bidStartPrice#投初始价
            if len(listPrice) > lp['bidRanking']:
                if curInd <= lp['bidRanking']:
                    if len(listPrice) >= lp['bidRanking']+1:
                        if nowBidPrice - listPrice[lp['bidRanking']] <= bid.bidUnit * (3+priceAdd): break #如果比下一名价格没有超过3倍，则不投
                        else: bidPrice = listPrice[lp['bidRanking']] + bid.bidUnit * lp['bidUnitMul']
                else: bidPrice = listPrice[lp['bidRanking']-1] + bid.bidUnit * lp['bidUnitMul']
            if bidPrice <= lp['limitPrice'] and bidPrice != nowBidPrice:#价格没有超出设定上限
                msg,sucPrice = sendPrice(threadName,dicBid['session'], bid.bidSeqNo, str(bidPrice), bid.bidPlusType, bid.bidID, lp['bidRanking'])
                if sucPrice > 0:
                    lock.acquire()
                    dicBid['price'] = sucPrice
                    dicBid['ranking'] = lp['bidRanking']
                    dicBid['message'].append({'msg':msg,'plist':listPrice,'time':timezone.now()})
                    lock.release()
                else:
                    lock.acquire()
                    dicBid['message'].append({'msg':msg,'plist':listPrice,'time':timezone.now()})
                    lock.release()
                break#成功后退出
        lock.acquire()
        dicBid['priceList']=listPrice
        dicBid['count'] += 1
        lock.release()
        nowTime = time.localtime(time.time())
        if (nowTime.tm_hour * 3600 + nowTime.tm_min * 60 + nowTime.tm_sec) >= timeEnd:break
        if onlyDebug: return
    print('sendTimes:',sendCnt)

def getChinaTime():
    timeStr = time.ctime()
    timeYear = time.strftime("%Y")
    timeHour = time.strftime("%H:%M:%S")
    timeStr = timeStr.replace(timeHour+' '+timeYear,'')
    timeNow = timeStr + timeYear + " " + timeHour + " GMT+0800 (中国标准时间)"
    return timeNow

def getBidPriceList(session,id,pt,cc,win=False):
    list_bid = 'list_bid'
    bid_price = 'bid_price'
    if win:
        list_bid = 'list_win'
        bid_price = 'win_bid_price'
    url = 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/swe_ADPlusBizService.asmx/GetPlusItem'
    data = ('{"plus_id": "'+ id +'","plus_type": "'+ pt +'","category_cd": "'+ cc +'","___cache_expire___": "'+ getChinaTime() +'"}').encode('utf-8')
    re = session.post(url,data = data)
    re.encoding = 'utf-8'
    listPrice = []
    if re.status_code == 200:
        jsd = re.json()['d']
        cnt = jsd['bid_count']
        mcnt = jsd['my_bid_count']
        v = jsd[list_bid]
        i = 1
        for one in v:
            listPrice.append(int(one[bid_price]))
            i += 1
        return listPrice
    else :
        print(re.text,'请求投标列表失败')
        print(id+pt+cc, '请求投标列表失败')
    return []

def getBidsLink():
    timeFr = time.strftime("%Y-%m-%d")
    timeTo = (datetime.datetime.now()+datetime.timedelta(days=7)).strftime("%Y-%m-%d")
    url = 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/swe_ADPlusBizService.asmx/GetBiddingList'
    postData = ('{"bid_end_dt": "'+ timeTo +'","bid_start_dt": "'+ timeFr +
    '","bid_stat": "","category": "","plus_type": "","srch_option": "I","srch_value": "","___cache_expire___": "'+ 
    getChinaTime() +'"}').encode('utf-8')
    return url,postData

def sessionSetCookie(session,cookies):
    for cookie in cookies:
        session.cookies.set(cookie['name'], cookie['value'])
    session.headers.update({'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36',
                        'referer': 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/ADPlus/ADPlusBiddingHistory.aspx',
                        'accept': '*/*','Accept-Encoding': 'gzip, deflate','Accept-Language': 'zh-CN',
                        'Cache-Control': 'no-cache','Content-Length': '148','Content-Type': 'application/json','Host': 'qsm.qoo10.jp'})

#更新Session
def updateSessions(sessionList):
    jooAcs = joo10Account.objects.all()
    ind = 0
    for joo in jooAcs:
        if joo.jooCookie == '' or joo.jooID == '':continue
        session = requests.Session()
        sessionSetCookie(session,eval(joo.jooCookie))
        joo10Bid.objects.filter(jooID = joo.jooID).update(bidSessionID = ind)
        joo10Account.objects.filter(jooID = joo.jooID).update(jooSessionID = ind)
        sessionList.append(session)
        ind += 1
    return jooAcs

#保存投标结果数据到文件
def saveBids(sessionList,userID='',saveToMql = True,saveToLog = False,saveToJoos = False):    
    dicWinBidPrice = {}
    updateSessions(sessionList)
    if userID=='':jooAcs = joo10Account.objects.all()
    else:         jooAcs = joo10Account.objects.filter(userID=userID)
    ind = 0
    if saveToMql and userID != '':currentBid.objects.filter(userID=userID).delete()  #如果存数据库，先删除旧的
    for joo in jooAcs:
        #if joo.jooID == '286654966':continue
        session = sessionList[joo.jooSessionID]
        if saveToJoos:# if no bids, continue
            bs = joo10Bid.objects.filter(jooID = joo.jooID)
            if len(bs) == 0:continue
        url,postData=getBidsLink()
        try:
            resp = session.post(url,data=postData,timeout=10)
        except Exception as e:
            print(joo.jooID,'saveBids Error 206:',e)
            continue
        finally:
            pass
        resp.encoding = 'utf-8'
        if resp.status_code == 200:
            js = resp.json()['d']['Rows']
            if len(js) == 0:
                print(joo.jooID,"投标列表无数据")
                continue
            if saveToJoos:
                bidUpdates = joo10Bid.objects.filter(jooID = joo.jooID)
                #print(len(bidUpdates))
                #print(js)
                if len(bidUpdates) == 0 or len(js) == 0:continue
                for one in js:
                    for bidUp in bidUpdates:               
                       bidID = int(one['plus_bid_no'])
                       if one['bid_stat'] != 'S2':continue   #如果是取消的号，下一个
                       if bidID != bidUp.bidID:continue
                       bidUpOne = joo10Bid.objects.filter(bidID = bidID)
                       bidUpOne.update(bidPlusID=one['plus_id'],bidPlusType=one['plus_type'],bidCategoryCd=one['category_cd'],
                       bidCurrentRanking=int(one['rank_no']),bidCurrentPrice=int(one['bid_price']),bidStartPrice=int(one['bid_price']),
                       bidUnit=int(one['bid_unit']),bidSeqNo=one['seq_no'],bidPlusBidNo=one['plus_bid_no'])
            if saveToMql:
                for one in js:
                    if one['bid_stat'] != 'S2':continue
                    plusStr = '{0}{1}{2}'.format(one['plus_id'],one['plus_type'],one['category_cd'])
                    if userID == '':continue
                    currentBid.objects.create(userID=userID,jooID=joo.jooID,bidID=one['plus_bid_no'],bidGoodID=one['gd_no'],bidPlusKey = one['category'],
                    bidCurrentRanking=one['rank_no'],bidCurrentPrice=one['bid_price'],bidCurrentPriceQ=one['total_bid_price'],
                    bidStartData=one['bid_start_dt'],bidShowTime = one['new_bid_date'],bidSeqNo=one['seq_no'],bidPlusStr=plusStr)
            if saveToLog:
                #print(len(js),end=' ')
                for one in js:
                    plusStr = '{0}{1}{2}'.format(one['plus_id'],one['plus_type'],one['category_cd'])
                    if plusStr not in dicWinBidPrice:                  
                        try:
                            priceList = getBidPriceList(session,str(one['plus_id']),str(one['plus_type']),str(one['category_cd']),True)
                        except Exception as e:
                            print(joo.jooID,'saveBids Error 242:',e)
                            continue
                        finally:
                            pass
                        dicWinBidPrice[plusStr] = {}
                        for pr in priceList:
                            dicWinBidPrice[plusStr][pr] = [one['category']]
                    dicWinBidPrice[plusStr][int(one['bid_price'])] = [one['category'],joo.jooID,one['bid_stat'],one['bid_start_dt'],one['gd_no']]
        else:
            print(resp.text)
            print(joo.jooID,"请求投标历史失败")
    if saveToLog:
        if not os.path.exists('./static/dailyBids'):os.mkdir('./static/dailyBids')
        fileName = './static/dailyBids/'+ userID[:5] + time.strftime('%Y%m%d')+'.xlsx'
        wb = openpyxl.Workbook()
        st = wb.active
        row = 1
        for (k,v) in dicWinBidPrice.items():
            i = 1
            for (kp,vp) in v.items():
                if len(vp) < 5:st.append([row,k,vp[0],i,kp])#st.cell(row=row,column=1,value=row)
                else:st.append([row,k,vp[0],i,kp,vp[1],vp[2],vp[3],vp[4]])
                i += 1
                row += 1
        wb.save(fileName)

def creatThreading(joos):
    global gloBidDic
    gloBidDic.clear()
    sessionList = []
    updateSessions(sessionList)
    bids = joo10Bid.objects.filter(jooID__in = joos)
    thList = []
    print('报价线程开始:', time.localtime(time.time()))   
    i = 1
    time1 = time.time()
    ordersCnt = 1
    if manyOrdersSend:ordersCnt = 1000
    for j in range(ordersCnt):
        for bid in bids:
            if bid.bidCurrentPrice == 0:
                print(bid.bidID, "未更新投标参数，跳过投标")
                continue
            if bid.bidID not in gloBidDic:
                gloBidDic[bid.bidID] = {'session':sessionList[bid.bidSessionID],'bid':bid,'price':bid.bidCurrentPrice,
                'message':[],'messageUpTo':[],'priceList':[],'ranking':bid.bidCurrentRanking,'count':0,'Qoo':bid.jooID}
            thread = ThreadBid(i,'O' + str(i), bid.bidID)
            thread.start()
            thList.append(thread)
            i += 1
    for th in thList:
        th.join()
    sessionList.clear()
    time2 = time.time()
    print('报价总用时：',time2 - time1)
    print("报价线程结束:",time.localtime(time.time()))
    saveDateToLog()

def saveDateToLog():    
    time.sleep(random.randint(0,5))
    strToFile = []
    for (k,v) in gloBidDic.items():
        strToFile.append(v['Qoo']+'\n')
        #ranking = getNowRanking(v['priceList'],v['price'])
        ranking = v['ranking']
        strToFile.append(str(('标号:',k,'报价:',v['price'],'名次:',ranking,'获取报价次数:',v['count']))+'\n')
        for msgOne in v['message']:
            strToFile.append('{}\n'.format(msgOne))
        for msgOne in v['messageUpTo']:
            strToFile.append('{}\n'.format(msgOne))
        strToFile.append(str(v['priceList'])+'\n')
        lastMsg = v['message'][-1:]
        #print(lastMsg)
        if lastMsg:joo10Bid.objects.filter(bidID=k).update(bidWinPrice=v['price'],bidWinInd=ranking,bidCurrentPrice=v['price'],bidWinTime=lastMsg[0]['time'])
        else:      joo10Bid.objects.filter(bidID=k).update(bidWinPrice=v['price'],bidWinInd=ranking,bidCurrentPrice=v['price'])
    if not os.path.exists('./static/BidLog'):os.mkdir('./static/BidLog')
    fileName = './static/BidLog/'+time.strftime('%Y%m%d')+'.py'
    with open(fileName,'a') as f:
        f.writelines(strToFile)

def work(sleepSec,joos,debug):
    global onlyDebug
    onlyDebug = debug
    try:   
        creatThreading(joos)
    except Exception as e:
        print(time.asctime(), "  Error:" , e)

def setPidForQooID(pid):
    joos = joo10Account.objects.all()
    jID = ''
    for joo in joos:
        jooID = joo.jooID
        if not joo.jooRun:continue
        if joo.jooRunPid == 0:
            joo10Account.objects.filter(jooID=jooID).update(jooRunPid=pid)
            jID = jooID
            break
    return jID
    
# if __name__ == "__main__":
#     sessionList = []
#     saveBids(sessionList,'chinazyl2013@163.com',False,True)
