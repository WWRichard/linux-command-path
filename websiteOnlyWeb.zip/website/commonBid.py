import threading,time,os,requests,json,datetime,random,openpyxl
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "website.settings")
import django
django.setup()
from django.utils import timezone
from joo10.models import joo10Account,joo10Bid,currentBid

gloBidDic = {}
lock = threading.Lock()

exitFlag = 0


def getChinaTime():
    timeStr = time.ctime()
    timeYear = time.strftime("%Y")
    timeHour = time.strftime("%H:%M:%S")
    timeStr = timeStr.replace(timeHour+' '+timeYear,'')
    timeNow = timeStr + timeYear + " " + timeHour + " GMT+0800 (中国标准时间)"
    return timeNow

def getBidsLink():
    timeFr = time.strftime("%Y-%m-%d")
    timeTo = (datetime.datetime.now()+datetime.timedelta(days=7)).strftime("%Y-%m-%d")
    url = 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/swe_ADPlusBizService.asmx/GetBiddingList'
    postData = ('{"bid_end_dt": "'+ timeTo +'","bid_start_dt": "'+ timeFr +
    '","bid_stat": "","category": "","plus_type": "","srch_option": "I","srch_value": "","___cache_expire___": "'+ 
    getChinaTime() +'"}').encode('utf-8')
    return url,postData

def sessionSetCookie(session,cookies):
    for cookie in cookies:
        session.cookies.set(cookie['name'], cookie['value'])
    session.headers.update({'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36',
                        'referer': 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/ADPlus/ADPlusBiddingHistory.aspx',
                        'accept': '*/*','Accept-Encoding': 'gzip, deflate','Accept-Language': 'zh-CN',
                        'Cache-Control': 'no-cache','Content-Length': '148','Content-Type': 'application/json','Host': 'qsm.qoo10.jp'})

#更新Session
def updateSessions(sessionList):
    jooAcs = joo10Account.objects.all()
    ind = 0
    for joo in jooAcs:
        if joo.jooCookie == '' or joo.jooID == '':continue
        session = requests.Session()
        sessionSetCookie(session,eval(joo.jooCookie))
        joo10Bid.objects.filter(jooID = joo.jooID).update(bidSessionID = ind)
        joo10Account.objects.filter(jooID = joo.jooID).update(jooSessionID = ind)
        sessionList.append(session)
        ind += 1
    return jooAcs

#保存投标结果数据到文件
def saveBids(sessionList,userID='',saveToMql = True,saveToLog = False,saveToJoos = False):    
    dicWinBidPrice = {}
    updateSessions(sessionList)
    if userID=='':jooAcs = joo10Account.objects.all()
    else:         jooAcs = joo10Account.objects.filter(userID=userID)
    ind = 0
    if saveToMql and userID != '':currentBid.objects.filter(userID=userID).delete()  #如果存数据库，先删除旧的
    for joo in jooAcs:
        #if joo.jooID == '286654966':continue
        session = sessionList[joo.jooSessionID]
        if saveToJoos:# if no bids, continue
            bs = joo10Bid.objects.filter(jooID = joo.jooID)
            if len(bs) == 0:continue
        url,postData=getBidsLink()
        try:
            resp = session.post(url,data=postData,timeout=10)
        except Exception as e:
            print(joo.jooID,'saveBids Error 206:',e)
            continue
        finally:
            pass
        resp.encoding = 'utf-8'
        if resp.status_code == 200:
            js = resp.json()['d']['Rows']
            if len(js) == 0:
                print(joo.jooID,"投标列表无数据")
                continue
            if saveToMql:
                for one in js:
                    if one['bid_stat'] != 'S2':continue
                    plusStr = '{0}{1}{2}'.format(one['plus_id'],one['plus_type'],one['category_cd'])
                    if userID == '':continue
                    currentBid.objects.create(userID=userID,jooID=joo.jooID,bidID=one['plus_bid_no'],bidGoodID=one['gd_no'],bidPlusKey = one['category'],
                    bidCurrentRanking=one['rank_no'],bidCurrentPrice=one['bid_price'],bidCurrentPriceQ=one['total_bid_price'],
                    bidStartData=one['bid_start_dt'],bidShowTime = one['new_bid_date'],bidSeqNo=one['seq_no'],bidPlusStr=plusStr)
        else:
            print(resp.text)
            print(joo.jooID,"请求投标历史失败")

# if __name__ == "__main__":
#     sessionList = []
#     saveBids(sessionList,'chinazyl2013@163.com',False,True)