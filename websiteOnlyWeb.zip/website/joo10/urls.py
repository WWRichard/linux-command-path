from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.login,name='login'),
    path('user',views.user,name='user'),
    path('dailyBids',views.dailyBids,name='dailyBids'),
    path('dailypy',views.dailyPy,name='dailyPy'),
]