#爬虫
import requests
import json
import time
import datetime
from . import models
#================================================爬虫代码============================================
def getPrice(session,id,pt,cc):
    url = 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/swe_ADPlusBizService.asmx/GetPlusItem'
    data = {'plus_id':id,'plus_type':pt,'category_cd':cc,'___cache_expire___':'Sun Jun 7 00:27:12 UTC+0800 2020'}
    dataStr = json.dumps(data)
    re = session.post(url,data = dataStr)
    re.encoding = 'utf-8'
    listPrice = []
    if re.status_code == 200:
        jsd = re.json()['d']
        cnt = jsd['bid_count']
        print('当前投标个数：',cnt)
        mcnt = jsd['my_bid_count']
        v = jsd['list_bid']
        print('当前投标价排名：', end = '  ')
        i = 1
        for one in v:
            print(i, one['bid_price'], end='   ')
            listPrice.append(int(one['bid_price']))
            i += 1
        print('')
        return listPrice
    else :
        print('请求失败')
    return []

def sendPrice(session,no,pr,ty,ticket,index):    
    url = 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/swe_ADPlusBizService.asmx/UpdateBiddingInfoBatch'
    data = {'bids':[
        {'type':'U','seq_no':no,'bid_price':pr,'landing_type':'','landing_url':'','img_url':'','gd_no':'','sid':'','display_type':ty}
    ]}
    re = session.post(url, data = json.dumps(data))
    re.encoding = 'utf-8'
    if re.status_code == 200:
        js = re.json()['d']['ResultMsg']
        message = ''
        if js == 'SUCCESS':
            message = '投标号：',ticket,'投标成功，中标价：',pr,'名次：',index
        elif js == 'FAIL[-5]':
            message = '现在不是投标时间'            
        else: 
            message = js
        models.joo10Bid.objects.filter(bidID=int(ticket)).update(bidSendMessage=message)
    else: print('发送投票请求投票失败')

def sessionSetCookie(session,cookies):
    for cookie in cookies:
        session.cookies.set(cookie['name'], cookie['value'])
    session.headers.update({'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36',
                      'referer': 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/ADPlus/ADPlusBiddingHistory.aspx',
                      'accept': '*/*','Accept-Encoding': 'gzip, deflate','Accept-Language': 'zh-CN',
                      'Cache-Control': 'no-cache','Content-Length': '148','Content-Type': 'application/json','Host': 'qsm.qoo10.jp'})

def getBidsLink():
    timeStr = time.ctime()
    timeYear = time.strftime("%Y")
    timeHour = time.strftime("%H:%M:%S")
    timeStr = timeStr.replace(timeHour+' '+timeYear,'')
    timeNow = timeStr + timeYear + " " + timeHour + " GMT+0800 (中国标准时间)"
    timeFr = time.strftime("%Y-%m-%d")
    timeTo = (datetime.datetime.now()+datetime.timedelta(days=7)).strftime("%Y-%m-%d")
    url = 'https://qsm.qoo10.jp/GMKT.INC.Gsm.Web/swe_ADPlusBizService.asmx/GetBiddingList'
    postData = ('{"bid_end_dt": "'+ timeTo +'","bid_start_dt": "'+ timeFr +'","bid_stat": "","category": "","plus_type": "","srch_option": "I","srch_value": "","___cache_expire___": "'+ timeNow +'"}').encode('utf-8')
    return url,postData

def loopAccounts(session,userID="",runType=0):
    joos = models.joo10Account.objects.all()
    if runType == 1:models.currentBid.objects.filter(userID = userID).delete()
    for joo in joos:
        print(userID,joo.userID)
        if userID != '' and userID != joo.userID: continue  #这只是一次指定用户的投标测试
        jooID = joo.jooID
        cookies = joo.jooCookie
        if cookies == '' or len(cookies) == 0:continue
        sessionSetCookie(session,eval(cookies))
        url,postData=getBidsLink()
        resp = session.post(url,data=postData)
        resp.encoding = 'utf-8'
        if resp.status_code == 200:
            print('请求投标历史列表成功')  
            js = resp.json()['d']['Rows']
            if len(js) == 0:print("投标列表无数据")            
            if runType == 1: #当前任务只获取历史列表
                for one in js:
                    if one['bid_stat'] != 'S2':continue
                    models.currentBid.objects.create(userID=userID,jooID=jooID,bidID=one['plus_bid_no'],bidGoodID=one['gd_no'],bidKey = one['category'],
                    bidCurrentRanking=one['rank_no'],bidCurrentPrice=one['bid_price'],bidCurrentPriceQ=one['total_bid_price'],
                    bidStartData=one['bid_start_dt'],bidShowTime = one['new_bid_date'],bidSeqNo=one['seq_no'])
                continue
            print('获取投标历史',len(js),'个')
            bids  = models.joo10Bid.objects.filter(jooID=jooID)
            loopBid(session,js,bids)
            # for one in js:
            #     print('投标号：',one['plus_bid_no'],'商品编码：',one['gd_no'],'投标价排序：',one['rank_no'],
            #         '投标价：',one['bid_price'],'需要Q货币：',one['total_bid_price'],
            #         '开始日：',one['bid_start_dt'])
            # for bid in bids:
            #     print(bid.bidID)

def loopBid(session,webList,tagList):
    for wbid in webList:
        for dbid in tagList:
            if wbid['plus_bid_no'] != dbid.bidID:continue
            listPrice = getPrice(session,wbid['plus_id'],wbid['plus_type'],wbid['category_cd'])
            if len(listPrice) == 0:
                print('获取报价异常')#没有人投标，至少应该有自己的
                continue
            curInd = int(wbid['rank_no'])
            # sendPrice(session,wbid['seq_no'], str(500), wbid['plus_type'], wbid['plus_bid_no'],dbid.bidRanking1)
            # return
            if curInd > dbid.bidRanking1:
                bidPrice = wbid['start_price']
                if len(listPrice) > dbid.bidRanking1:#当前报价个数达到目标名次个数
                    bidPrice = listPrice[dbid.bidRanking1-1]+int(wbid['bid_unit'])
                if bidPrice <= dbid.bidPriceMax1: #上限价格以内
                    sendPrice(session,wbid['seq_no'], str(bidPrice), wbid['plus_type'], wbid['plus_bid_no'],dbid.bidRanking1)
                else:#价格超过第一目标，看第二目标
                    bidPrice = wbid['start_price']
                    if len(listPrice) > dbid.bidRanking2:bidPrice = listPrice[dbid.bidRanking2-1]+int(wbid['bid_unit'])#第二目标个数
                    if bidPrice <= dbid.bidPriceMax2:
                        sendPrice(session,wbid['seq_no'], str(bidPrice), wbid['plus_type'], wbid['plus_bid_no'],dbid.bidRanking2)
                    else: print("价格超过第二目标，报价失败")

# def getConfig():
#     lines = []
#     retList = []
#     try:
#         with open('config.csv','r') as f:
#             lines = f.readlines()
#     except:
#         print('打开配制文件 config.csv 失败')
#     for line in lines:
#         if line.find('投标号') >= 0: continue
#         li = line.strip('\n').split(',')
#         if len(li) >= 3:
#             retList.append([int(li[0]),int(li[1]),int(li[2])])
#     print('配制文件信息：',retList)
#     return retList