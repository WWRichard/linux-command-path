/*function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
function sendPost(ev){
    var output = false;
    var csrftoken = getCookie('csrftoken');
    $.ajax({
        method: "POST",
        url: "user",
        async: false,
        data: { postV1: ev, postV2: "Boston" },
        headers:{ "X-CSRFtoken":csrftoken},
        success:function(msg){output = msg;}
    });
    return output;
}
*/
jQuery(document).ready(function($){
    $('.change_language').change(function(e){
        e.preventDefault();
        $('#change_language_form').submit();
        return false;
    });
    $("#exampleFormControlFile1").change(function() {
        filename = this.files[0].name
        $('#fileNameLabel').text(filename);
        console.log(filename);
      });
});
$(function(){
    /*
	function showAuto(){
        var textLog = $('#textareaLog');
        if(textLog){
            var fullStr = '';
            var getStr = sendPost("")
            if(getStr == "")return;
            var longStr = (getStr + "\n" + textLog.text()).split('\n',14);
            longStr.forEach(function(element) {fullStr += element + "\n";});
            textLog.text(fullStr);
        }
    }
    setInterval(showAuto, 1000);
	*/
})